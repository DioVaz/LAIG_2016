%%%:- include('Teste.pl').
cls:-write('\e[2J'). %Clear Screen on 

%%%%%%%%%%%%%%% IMPRIME TAULEIRO %%%%%%%%%%%%%%%%%%%%%%%%%%%
print_list([]).
print_list([C|Rest]) :- 
							write(C),
							write(' '),
							print_list(Rest).
print_matrix([],_).
print_matrix([C|Rest],N):-
						Nr is N + 1,
						write(Nr),
						write(' '),
						print_list(C),
						nl,
						print_matrix(Rest,Nr).

print_coord:-
						write('  '),
						write('A'),
						write(' '),
						write('B'),
						write(' '),
						write('C'),
						write(' '),
						write('D'),
						write(' '),
						write('E'),
						nl.

print_tab(T,Rpool,Bpool):-
				nl,
				write('SIXTEEN STONE'),
				nl,
				nl,
				print_coord,
				Nr is 0,
				print_matrix(T,Nr),
				nl,
				write('    POOL'),
				nl,
				write('Red:'),
				write(Rpool), 
				write('  Blue:'),
				write(Bpool),
				nl,
				write(' ').


tab_init([ ['.','.','.','.','.'],
    	   ['.','.','.','.','.'],
    	   ['.','.','.','.','.'],
    	   ['.','.','.','.','.'],
    	   ['.','.','.','.','.'] ] ).

%%%% TESTAR PRINT_TAB
testar_p_tab :-
    tab_init(Teste),
    R is 0,
    B is 0,
    print_tab(Teste,R,B).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%% FIM IMPRIMIR TABULEIRO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%% MANIPULAR TABULEIRO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
set_piece_list(1, Elem, [_|L], [Elem|L]).
set_piece_list(I, Elem, [H|L], [H|ResL]):-
  I > 1,
  I1 is I-1,
  set_piece_list(I1, Elem, L, ResL).

set_piece_tabuleiro(1, Col, NewElem, [H|T], [NewH|T]) :-  set_piece_list(Col, NewElem, H, NewH).
set_piece_tabuleiro(Row, Col, NewElem, [H|T], [H|ResT]):-
  Row > 1,
  Row1 is Row-1,
  set_piece_tabuleiro(Row1, Col, NewElem, T, ResT).          
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%% VERIFICAR PEÇAS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
getListElemAt(1, [ElemAtTheHead|_], ElemAtTheHead).
getListElemAt(Pos, [_|RemainingElems], Elem):-
	Pos > 1,
	Pos1 is Pos-1,
	getListElemAt(Pos1, RemainingElems, Elem).


getMatrixElemAt(1, ElemCol, [ListAtTheHead|_], Elem):-
    getListElemAt(ElemCol, ListAtTheHead, Elem).

getMatrixElemAt(ElemRow, ElemCol, [_|RemainingLists], Elem):-
	ElemRow > 1,
	ElemRow1 is ElemRow-1,
	getMatrixElemAt(ElemRow1, ElemCol, RemainingLists, Elem).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%% UTILIDADES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
choose_piece(Player,Piece):-
	(	Player=1 -> (Piece = 'R');
		Player=2 -> (Piece = 'B')).

choose_enemy_piece(Player,Piece):-
	(	Player=1 -> (Piece = 'B');
		Player=2 -> (Piece = 'R')).

translateOrient(X, Y, O, X2, Y2) :-
	X3 is (-1), Y3 is (-1), YM is Y - 1, XM is X - 1, YP is Y + 1, XP is X + 1,
	(	O = 'N' -> (Y2 is YM,X2 is X);
		O = 'NE'-> (Y2 is YM, X2 is XP);
		O = 'E' -> (X2 is XP, Y2 is Y);
		O = 'SE'-> (Y2 is YP, X2 is XP);
		O = 'S' -> (Y2 is YP, X2 is X);
		O = 'SW'-> (Y2 is YP, X2 is XM);
		O = 'W' -> (X2 is XM, Y2 is Y);
		O = 'NW'-> (Y2 is YM, X2 is XM);
		X2 is X3, Y2 is Y3).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%% COLOCA PEÇA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
verifica_vazio(Bool,Coord_x,Coord_y,Tab_entrada):-
	getMatrixElemAt(Coord_y, Coord_x, Tab_entrada, Elemento),
	(	Elemento\= '.' -> (Bool = 1);
		Elemento = '.' -> (Bool = 0) 
							).

coord_AlphatoNum(Aplpha_x,Num_x):-
	(	Aplpha_x='A' -> (Num_x = 1);
		Aplpha_x='B' -> (Num_x = 2);
		Aplpha_x='C' -> (Num_x = 3);
		Aplpha_x='D' -> (Num_x = 4);
		Aplpha_x='E' -> (Num_x = 5) ).


put_piece(Player,Stack_entrada,Stack_saida,Tab_entrada,Tab_saida):-
	write('Select the column [A-E]'),
	nl,
	read(Alpha_x),
	coord_AlphatoNum(Alpha_x,Coord_x),
	write('Select the row [1-5]'),
	nl,
	read(Coord_y),
	choose_piece(Player,Piece),
	verifica_vazio(Bool,Coord_x,Coord_y,Tab_entrada),
	(	Bool=1 -> (put_piece(Player,Stack_entrada,Stack_saida,Tab_entrada,Tab_saida));
		Bool=0 -> (set_piece_tabuleiro(Coord_y,Coord_x,Piece,Tab_entrada,Tab_saida))
					),
	Stack_saida is Stack_entrada -1.

	%%%%% TESTAR COLOCAÇÃO DE PEÇA
	testar_colocar_peca:-
		tab_init(Teste),
		R is 1,
		B is 2,
		cls,
		print_tab(Teste,R,B),
		put_piece(1,R,Stack_saida,Teste,Tab_saida),
		cls,
		print_tab(Tab_saida,Stack_saida,B),
		put_piece(2,B,Stack_nova,Tab_saida,Tab_novo),
		cls,
		print_tab(Tab_novo,Stack_saida,Stack_nova).
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%% MOVER PEÇA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

move_piece(Player,Tab_entrada,Tab_saida):-
	choose_piece(Player,Piece),
	nl,
	write('Select the Stone you want to move'),
	nl,
	write('Column [A-E]'),
	nl,
	read(Alpha_x),
	coord_AlphatoNum(Alpha_x,Coord_x),
	write('Row [1-5]'),
	nl,
	read(Coord_y),
    getMatrixElemAt(Coord_y, Coord_x, Tab_entrada, Elem),
	(	Elem \= Piece -> (	write('That is not your stone, dude!'),
					nl,
					move_piece(Player,Tab_entrada,Tab_saida)
					);
		Elem =  Piece -> (	write('In which direction?'),
							read(Orient),
							write('Orient:'),
							write(Orient),
							nl,
							translateOrient(Coord_x,Coord_y,Orient,Dest_x,Dest_y),
							write('Dest_x:'),
							write(Dest_x),
							nl,
							write('Dest_y:'),
							write(Dest_y),
							%%check_capture(, Listanoncapturable),
							verifica_vazio(Bool,Dest_x,Dest_y,Tab_entrada),
							(	Bool=1 -> (	write('Cannot move there!'),
											move_piece(Player,Tab_entrada,Tab_saida)
											);
								Bool=0 -> (	set_piece_tabuleiro(Coord_y, Coord_x, '.', Tab_entrada, S),
											set_piece_tabuleiro(Dest_y, Dest_x, Elem, S, Tab_saida)
											)
							)
						 )
	).


	%%%%% TESTAR COLOCAÇÃO DE PEÇA
	testar_move:-
		tab_init(Teste),
		R is 5,
		B is 5,
		cls,
		print_tab(Teste,R,B),
		put_piece(1,R,Stack_saida,Teste,Tab_saida),
		cls,
		print_tab(Tab_saida,Stack_saida,B),
		put_piece(1,Stack_saida,Stack_nova,Tab_saida,Tab_novo),
		cls,
		print_tab(Tab_novo,Stack_nova,B),
		move_piece(1,Tab_novo,Tab_novissimo),
		cls,
		print_tab(Tab_novissimo,Stack_nova,B).

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FIM MOVER PEÇA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


check_capture(Player, Tab, 0, 0, LAlf, LNum):-
	write('esquisito').
	
check_capture(Player, Tab, 5, 0, LAlf, LNum):-
	check_capture(Player, Tab, 0, 0, LAlf, LNum).
	
check_capture(Player, Tab, 0, Row, LAlf,LNum) :-
	RowM is Row - 1, nl, write('0, row:   '), write(Row),
	check_capture(Player, Tab, 5, RowM, LAlf, LNum).
	
	
check_capture(Player, Tab, Col, Row, LAlf,LNum) :-
	RowM is Row - 1, ColM is Col - 1, RowP is Row + 1, ColP is Col + 1,
	Row2M is Row - 2, Col2M is Col - 2, Row2P is Row + 2, Col2P is Col + 2,
	choose_piece(Player, Piece),
	choose_enemy_piece(Player, EnemyPiece),
	getMatrixElemAt(Row, Col, Tab, Elem),
	LA = LAlf,
	LN = LNum,
	( Elem = Piece -> (getMatrixElemAt(RowP, ColP, Tab, Elem2), getMatrixElemAt(Row2P, Col2P, Tab, Elem3), 
						(Elem2 = EnemyPiece, Elem3 = Piece -> (write('chega1'),append(ColP, LAlf, LAlf2), append(RowP, LNum, LNum2));
							(getMatrixElemAt(RowP, Col, Tab, Elem4), getMatrixElemAt(Row2P, Col, Tab, Elem5), 
							(Elem4 = EnemyPiece, Elem5 = Piece -> (append([Col], LAlf, LAlf), append([RowP], LNum, LNum), write('chega00'));
								(getMatrixElemAt(RowP, ColM, Tab, Elem6), getMatrixElemAt(Row2P, Col2M, Tab, Elem7), 
								(Elem6 = EnemyPiece, Elem7 = Piece -> (write('chega3'),append([ColM], LAlf, LAlf), append(RowP, LNum, LNum2));
									(getMatrixElemAt(Row, ColM, Tab, Elem8), getMatrixElemAt(Row, Col2M, Tab, Elem9), 
									(Elem8 = EnemyPiece, Elem9 = Piece -> (write('chega4'),append(ColM, LAlf, LAlf2), append(Row, LNum, LNum2));
										(getMatrixElemAt(RowM, ColM, Tab, Elem10), getMatrixElemAt(Row2M, Col2M, Tab, Elem11), 
										(Elem10 = EnemyPiece, Elem11 == Piece -> (write('chega5'),append([ColM], LAlf, LAlf2),  append(RowM, LNum, LNum2));
											(getMatrixElemAt(RowM, Col, Tab, Elem12), getMatrixElemAt(Row2M, Col, Tab, Elem13),
											(Elem12 = EnemyPiece, Elem13 = Piece ->(append(Col, LAlf, LAlf2), append(RowM, LNum, LNum2));
												(getMatrixElemAt(RowM, ColP, Tab, Elem14), getMatrixElemAt(Row2M, Col2P, Tab, Elem15), 
												(Elem14 = EnemyPiece, Elem15 = Piece -> (write('chega7'),append(ColP, LAlf, LAlf2), append(RowM, LNum, LNum2));
													(getMatrixElemAt(Row, ColP, Tab, Elem16), getMatrixElemAt(Row, Col2P, Tab, Elem17), 
													(Elem16 = EnemyPiece, Elem17 = Piece -> (write('chega8'),append(ColP, LAlf, LAlf2), append(Row, LNum, LNum2));
														(nl,
														write(Row),
														nl,
														write(Col),
														Col33 is Col - 1,
														check_capture(Player, Tab, Col33, Row, LAlf2, LNum2))
													))
												))
											))
										)))
									))
								))
							))
						)
						
	).
				
	
	
	
teste_check_capture:-
		tab_init(Teste),
		R is 1,
		B is 2,
		cls,
		print_tab(Teste,R,B),
		put_piece(1,R,StackR,Teste,Tab_saida),
		cls,
		print_tab(Tab_saida,R,B),
		put_piece(2,B,StackB,Tab_saida,Tab_saida2),
		cls,
		print_tab(Tab_saida2,R,B),
		put_piece(1,StackR,StackR2,Tab_saida2,Tab_saida3),
		cls,
		print_tab(Tab_saida3,R,B),
		L1 = [],
		L2 = [],
		check_capture(1, Tab_saida3, 5, 5, L1, L2),
		nl,
		write(LAlf),
		nl,
		write(LNum).