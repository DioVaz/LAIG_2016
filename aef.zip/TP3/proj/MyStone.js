/**
 * MyStone
 * @constructor
 */
 function MyStone(scene, app, rb, w_at, x, z) {    // rb ->  1 = blue, 0 = red
 	CGFobject.call(this, scene);

	this.rb = rb;
	this.tex = app;
	this.picked = 0;
	this.where_at = w_at || 0; // LeftStack = -1; Board = 0; RightStack = 1;
	this.x = x || 0;
	this.z = z || 0;
	this.x_coord;
	this.z_coord;
	this.nextx;
	this.nextz;
	this.LinAnim;
 	this.piece = new MyUnitCubeQuad(scene);
 };

 MyStone.prototype = Object.create(CGFobject.prototype);
 MyStone.prototype.constructor = MyStone;

 MyStone.prototype.display = function() {
	 
	 //if it is in main board
	 
	 this.tex.apply();
	 if(this.where_at == 0){
	 this.calculate_spacial_coords();
	 this.scene.pushMatrix();
		this.scene.translate(this.x_coord,0.5,this.z_coord);
		 if(this.LinAnim != null && this.LinAnim.end == 0){
			this.LinAnim.doAnimation();
			this.scene.multMatrix(this.LinAnim.move());
		 }
		 if((this.rb == 0 && this.scene.registerbluestones) || (this.rb == 1 && this.scene.registerredstones))
			this.scene.clearPickRegistration();
		this.piece.display();
	this.scene.popMatrix();
	 }
	 else if(this.where_at == 1 || this.where_at == -1){
		 this.calculate_spacial_coords();
		 this.scene.pushMatrix();
			this.scene.translate(this.x_coord,0.5,this.z_coord);
			if(this.LinAnim != null && this.LinAnim.end == 0){
				this.LinAnim.doAnimation();
				this.scene.multMatrix(this.LinAnim.move());
			}
			this.piece.display();
		this.scene.popMatrix();
	 }
	 if(this.LinAnim.end != null && this.LinAnim.end == true)
	 {
		 this.where_at = this.where_at;
		 this.x = this.nextx;
		 this.z = this.nextz;
	 }
 	// TO DO
 };

 
 MyStone.prototype.calculate_spacial_coords = function(){
	 this.x_coord = -7 + (this.x * 2);
	 this.z_coord = -7 + (this.z * 2);
 };
 
 MyStone.prototype.change_coords = function(new_x, new_z){
	 // TO DO 
	 // ADD ANIMATION WHEN CHANGING DIFFERENT BOARDS
	 if(this.where_at==0){
		 var xdesl = new_x-this.x;
		 var zdesl = new_z- this.z;
		 if(xdesl==0 && zdesl!=0)
			 var PCs = [[0,0,0], [0,3,0], [0,3,zdesl*2], [0,0,zdesl*2]];
		 else if(xdesl != 0 && zdesl==0)
			 var PCs = [[0,0,0], [0,3,0], [xdesl*2,3,0], [xdesl*2,0,0]];
		 else if(xdesl == 0 && zdesl==0)
			 var PCs = [[0,0,0], [0,3,0], [0,0,0]];
		 else
			var PCs = [[0,0,0], [0,3,0], [xdesl*2, 3, 0], [xdesl*2, 3, zdesl*2], [xdesl*2, 0, zdesl*2]];
		 var llinAnim = new MyLinearAnim(this.scene, PCs, 2);
		 this.addAnimation(llinAnim);
		 this.nextx = new_x;
		 this.nextz = new_z;
	 }
	 else if(this.where_at==1){
		 var xdesl = 0.5*new_z - this.x; //new_z =  free stack place;
		 if(xdesl != 0)
			var PCs = [[0,0,0], [0,3,0], [xdesl*2, 3, 0], [xdesl*2, 0, 0]];
		 else
			var PCs = [[0,0,0], [xdesl, 3, 0], [xdesl*2, 0, 0]];
		 var llinAnim = new MyLinearAnim(this.scene, PCs, 0.1);
		 this.addAnimation(llinAnim);
		 this.nextx = xdesl;
		 this.nextz = this.z;
	 }
	 else if(this.where_at==-1){
		 var xdesl = -(0.5*new_z - this.x); //new_z =  free stack place;
		 if(xdesl != 0)
			var PCs = [[0,0,0], [0,3,0], [xdesl*2, 3, 0], [xdesl*2, 0, 0]];
		 else
			var PCs = [[0,0,0], [xdesl*2, 3, 0], [xdesl*2, 0, 0]];
		 var llinAnim = new MyLinearAnim(this.scene, PCs, 0.1);
		 this.addAnimation(llinAnim);
		 this.nextx = xdesl;
		 this.nextz = this.z;
	 }
 };
 
 MyStone.prototype.change_coords_from_red_stack = function(x,z){
		 this.where_at = 0;
		 var xdesl = x-this.x;
		 var zdesl = z- this.z;
		if(xdesl==0 && zdesl!=0)
			 var PCs = [[0,0,0], [0,3,0], [0,3,zdesl*2], [0,0,zdesl*2]];
		 else if(xdesl != 0 && zdesl==0)
			 var PCs = [[0,0,0], [0,3,0], [xdesl*2,3,0], [xdesl*2,0,0]];
		 else if(xdesl == 0 && zdesl==0)
			 var PCs = [[0,0,0], [0,3,0], [0,0,0]];
		 else
			var PCs = [[0,0,0], [0,3,0], [xdesl*2, 3, 0], [xdesl*2, 3, zdesl*2], [xdesl*2, 0, zdesl*2]];
		 var llinAnim = new MyLinearAnim(this.scene, PCs, 2);
		 this.addAnimation(llinAnim);
		 this.nextx = x;
		 this.nextz = z;
 }
 MyStone.prototype.change_coords_from_blue_stack = function(x,z){
		 this.where_at = 0;
		 var xdesl = x-this.x;
		 var zdesl = z- this.z;
		 if(xdesl==0 && zdesl!=0)
			 var PCs = [[0,0,0], [0,3,0], [0,3,zdesl*2], [0,0,zdesl*2]];
		 else if(xdesl != 0 && zdesl==0)
			 var PCs = [[0,0,0], [0,3,0], [xdesl*2,3,0], [xdesl*2,0,0]];
		 else if(xdesl == 0 && zdesl==0)
			 var PCs = [[0,0,0], [0,3,0], [0,0,0]];
		 else
			var PCs = [[0,0,0], [0,3,0], [xdesl*2, 3, 0], [xdesl*2, 3, zdesl*2], [xdesl*2, 0, zdesl*2]];
		 var llinAnim = new MyLinearAnim(this.scene, PCs, 2);
		 this.addAnimation(llinAnim);
		 this.nextx = x;
		 this.nextz = z;
 }
 MyStone.prototype.addAnimation = function(Anim){
	 this.LinAnim = Anim;
 };