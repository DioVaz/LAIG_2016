function MyStack(scene, rb, args) {
	this.scene = scene;
    this.args = args || [20];
    this.nrParts = this.args[0];
	this.rb = rb;   // r = -1; b = 1;

	this.pieces_vec = [];
	this.st = new MyStone(this.scene);
    var nurbsSurface = new CGFnurbsSurface(1, 1, [0, 0, 1, 1], [0, 0, 1, 1], [
        [
            [0.5, 0, -0.5, 1],
            [0.5, 0, 0.5, 1]
        ],
        [
            [-0.5, 0, -0.5, 1],
            [-0.5, 0, 0.5, 1, 1]
        ]
    ]);
    var getSurfacePoint = function(u, v) {
        return nurbsSurface.getPoint(u, v);
    };
    CGFnurbsObject.call(this, scene, getSurfacePoint, this.nrParts, this.nrParts);
}

MyStack.prototype = Object.create(CGFnurbsObject.prototype);
MyStack.prototype.constructor = MyStack;

MyStack.prototype.updateTex = function(ampS, ampT) {};

MyStack.prototype.display2 = function(){
	for(i=0; i<this.pieces_vec.length; i++){
		//console.log(this.pieces_vec[i]);
		this.scene.pushMatrix();
			if(this.pieces_vec[i].where_at == 1){	
				this.scene.pieceapp.apply();
				this.scene.translate(17.5,0,7);
			}
			else{
				this.scene.pieceappred.apply();
				this.scene.translate(-3,0,7);
			}
			this.pieces_vec[i].display();
		this.scene.popMatrix();
		if(this.pieces_vec[i].LinAnim != null && this.pieces_vec[i].LinAnim.end != true)
			break;
	}
	this.scene.pushMatrix();
		this.scene.boardtex.apply();
		if(this.rb == 1)
			this.scene.translate(14.5, 0, 0);
		else
			this.scene.translate(-14.5, 0, 0);
		this.scene.scale(10, 1, 1);
		this.drawElements(this.primitiveType);
	this.scene.popMatrix();
};


MyStack.prototype.addStone = function(stone,x,z){
	console.log(this.getFreeStackPlace());
	stone.change_coords(x,this.getFreeStackPlace());
	this.pieces_vec.push(stone);
};

MyStack.prototype.getFreeStackPlace = function(){
	return this.pieces_vec.length;
}

MyStack.prototype.removePiece = function(){
	var stone = this.pieces_vec.pop();
	return stone;
}