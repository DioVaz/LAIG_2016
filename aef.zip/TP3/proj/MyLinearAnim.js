/**
 * MyLinearAnim
 * @constructor
 */

 // It is used a different LinearAnimation from the previous TP
 // because some bugs were found in the previous implementation
 // Base implementation credits go to: 
 // Eduardo Reis up201303832
 // João Duarte  up201303834
 
 // It has posteriorly been patched, bugfixed and adapted in order to better serve its purpose on our project
 
 
var start = null ;
var pontos = 0;
var i = 0;
function MyLinearAnim(scene, PControlo, tempo) 
{
    this.scene = scene;
    this.x = 0;
    this.y = 0;
    this.z = 0;
    this.PControlo = PControlo;
    this.tempo = tempo;
    console.log(this.PControlo);
    this.dist = 0;
    this.calculaDistancia();
    this.matrix = mat4.create();
    this.estado = 1;
    this.angPercorrido = null ;
    this.angRotacao = null ;
    this.end = 0;
}

MyLinearAnim.prototype = new MyAnimation(this.scene);
MyLinearAnim.prototype.constructor = MyLinearAnim;

MyLinearAnim.prototype.calculaDistancia = function() 
{
    for (var i = 0; i < this.PControlo.length - 1; i++) 
    {
        this.dist += Math.sqrt(Math.pow((this.PControlo[i + 1][0] - this.PControlo[i][0]), 2) 
        + Math.pow((this.PControlo[i + 1][1] - this.PControlo[i][1]), 2) 
        + Math.pow((this.PControlo[i + 1][2] - this.PControlo[i][2]), 2));
    }
};

MyLinearAnim.prototype.doAnimation = function() 
{
    var currentTime = Date.now();
    
    if (!start)
        start = currentTime;
    
    if (this.lastAnimation) 
    {
        var delta = currentTime - this.lastAnimation;
        var progresso = (currentTime - start) / 1000;
        this.v = (this.dist / this.tempo) * delta / 1000
        if (1) 
        {
            if (pontos >= this.PControlo.length - 1) 
            {
                this.end = 1;
				pontos = 0;
            } 
            else if (this.estado == 1) 
            {
                if (this.PControlo[pontos][0] != this.PControlo[pontos + 1][0]) // xx
                {
                    if (this.PControlo[pontos][0] < this.PControlo[pontos + 1][0]) 
                    {
                        this.x += this.v;
                        if (this.x >= this.PControlo[pontos + 1][0]) {
                            pontos++;
                            this.calculaAngulo();
                        }
                    } 
                    else 
                    {
                        this.x -= this.v;
                        if (this.x <= this.PControlo[pontos + 1][0]) {
                            pontos++;
                            this.calculaAngulo();
                        }
                    }
                } 
                else if (this.PControlo[pontos][1] != this.PControlo[pontos + 1][1]) //yy
                {
                    if (this.PControlo[pontos][1] < this.PControlo[pontos + 1][1]) 
                    {
                        this.y += this.v;
                        if (this.y >= this.PControlo[pontos + 1][1]) {
                            pontos++;
                            this.calculaAngulo();
                        }
                    } 
                    else 
                    {
                        this.y -= this.v;
                        if (this.y <= this.PControlo[pontos + 1][1]) {
                            pontos++;
                            this.calculaAngulo();
                        }
                    }
                } 
                else if (this.PControlo[pontos][2] != this.PControlo[pontos + 1][2]) //zz
                {
                    if (this.PControlo[pontos][2] < this.PControlo[pontos + 1][2]) 
                    {
                        this.z += this.v;
                        if (this.z >= this.PControlo[pontos + 1][2]) {
                            pontos++;
                            this.calculaAngulo();
                        }
                    } 
                    else 
                    {
                        this.z -= this.v;
                        if (this.z <= this.PControlo[pontos + 1][2]) {
                            pontos++;
                            this.calculaAngulo();
                        }
                    }
                }
            
            } 
            else if (this.estado == 0) 
            {
                this.angPercorrido += this.v / 2;
                if (this.angPercorrido > this.angRotacao)
                    this.angPercorrido = this.angRotacao;
                
                if (this.angPercorrido == this.angRotacao)
                    this.estado = 1;                
            }
            mat4.identity(this.matrix);
            mat4.translate(this.matrix, this.matrix, [this.x, this.y, this.z]);
            mat4.rotate(this.matrix, this.matrix, this.angPercorrido, [0, 1, 0]);
        }
    }
    this.lastAnimation = currentTime;
    return this.end;
}


MyLinearAnim.prototype.calculaAngulo = function() 
{
    if (pontos < this.PControlo.length - 1) 
    {
        var angulo = Math.acos((((this.PControlo[pontos][0] - this.PControlo[pontos - 1][0]) 
        * (this.PControlo[pontos + 1][0] - this.PControlo[pontos][0])) 
        + ((this.PControlo[pontos][1] - this.PControlo[pontos - 1][1]) 
        * (this.PControlo[pontos + 1][1] - this.PControlo[pontos][1])) 
        + ((this.PControlo[pontos][2] - this.PControlo[pontos - 1][2]) 
        * (this.PControlo[pontos + 1][2] - this.PControlo[pontos][2]))) 
        / 
        ((Math.sqrt(Math.pow((this.PControlo[pontos][0] - this.PControlo[pontos - 1][0]), 2) 
        + Math.pow((this.PControlo[pontos][1] - this.PControlo[pontos - 1][1]), 2) 
        + Math.pow((this.PControlo[pontos][2] - this.PControlo[pontos - 1][2]), 2))) 
        * 
        (Math.sqrt(Math.pow((this.PControlo[pontos + 1][0] - this.PControlo[pontos][0]), 2) 
        + Math.pow((this.PControlo[pontos + 1][1] - this.PControlo[pontos][1]), 2) 
        + Math.pow((this.PControlo[pontos + 1][2] - this.PControlo[pontos][2]), 2)))))
        
        if (angulo != 0 && this.PControlo[pontos][1] == this.PControlo[pontos + 1][1]) //this.estado = 0 - esta a mudar orientaçao
        {
            //this.estado = 1 - esta a fazer as translações pedidas
            this.estado = 0;
            this.angRotacao = angulo;
        } 
        else {
            this.estado = 1;
        }
    }
}

MyLinearAnim.prototype.copia = function()
{
    return new MyLinearAnim(this.scene, this.PControlo, this.tempo);
}