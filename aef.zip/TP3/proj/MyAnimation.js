/**
 * MyAnimation
 * @constructor
 */

 function MyAnimation(scene)
{
	this.scene = scene;
}

MyAnimation.prototype.move = function()
{
	return this.matrix;
}