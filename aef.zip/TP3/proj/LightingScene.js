var degToRad = Math.PI / 180.0;



function LightingScene() {
	CGFscene.call(this);
}

LightingScene.prototype = Object.create(CGFscene.prototype);
LightingScene.prototype.constructor = LightingScene;

LightingScene.prototype.init = function(application) {
	CGFscene.prototype.init.call(this, application);

	this.initCameras();

	this.initLights();
	this.enableTextures(true);
	this.gl.clearColor(0.0, 0.0, 0.0, 1.0);
	this.gl.clearDepth(100.0);
	this.gl.enable(this.gl.DEPTH_TEST);
	this.gl.enable(this.gl.CULL_FACE);
	this.gl.depthFunc(this.gl.LEQUAL);

	this.axis = new CGFaxis(this);

	// Scene elements
	this.firsttime = true;
	this.registerbluestones = false;
	this.registerredstones = false;
	this.displaypickb = false;
	
	
	this.inter = this.interface;
	
	this.boardtex = new CGFappearance(this);
	this.boardtex.loadTexture("../resources/images/board.png");
	
	this.pieceapp = new CGFappearance(this);
	this.pieceapp.loadTexture("../resources/images/darkblue.jpg");
	this.pieceappred = new CGFappearance(this);
	this.pieceappred.loadTexture("../resources/images/brightred.jpg");
	
	this.pickBoardtex = new CGFappearance(this);
	this.pickBoardtex.loadTexture("../resources/images/shadedgreen.jpg");
	
	
	this.defapp = new CGFappearance(this);
	
	this.bpiece1 = new MyStone(this, this.pieceapp, 1, 1, 0, 0);  
	this.bpiece2 = new MyStone(this, this.pieceapp, 1, 1, 0, 0);
	this.bpiece3 = new MyStone(this, this.pieceapp, 1, 1, 0, 0);
	this.bpiece4 = new MyStone(this, this.pieceapp, 1, 1, 0, 0);
	this.bpiece5 = new MyStone(this, this.pieceapp, 1, 1, 0, 0);
	this.bpiece6 = new MyStone(this, this.pieceapp, 1, 1, 0, 0);
	this.bpiece7 = new MyStone(this, this.pieceapp, 1, 1, 0, 0);
	this.bpiece8 = new MyStone(this, this.pieceapp, 1, 1, 0, 0);
	
	this.rpiece1 = new MyStone(this, this.pieceappred, 0, -1, 0, 0);
	this.rpiece2 = new MyStone(this, this.pieceappred, 0, -1, 0, 0);
	this.rpiece3 = new MyStone(this, this.pieceappred, 0, -1, 0, 0);
	this.rpiece4 = new MyStone(this, this.pieceappred, 0, -1, 0, 0);
	this.rpiece5 = new MyStone(this, this.pieceappred, 0, -1, 0, 0);
	this.rpiece6 = new MyStone(this, this.pieceappred, 0, -1, 0, 0);
	this.rpiece7 = new MyStone(this, this.pieceappred, 0, -1, 0, 0);
	this.rpiece8 = new MyStone(this, this.pieceappred, 0, -1, 0, 0);
	
	
	
	
	this.plane = new MyPlane(this);
	//this.plane.addStone(this.bpiece1, 0, 0);
	
	this.bstack = new MyStack(this, 1);
	this.bstack.addStone(this.bpiece1);
	this.bstack.addStone(this.bpiece2);
	this.bstack.addStone(this.bpiece3);
	this.bstack.addStone(this.bpiece4);
	this.bstack.addStone(this.bpiece5);
	this.bstack.addStone(this.bpiece6);
	this.bstack.addStone(this.bpiece7);
	this.bstack.addStone(this.bpiece8);
	// automatic placement in free slot
	
	this.rstack = new MyStack(this, -1);
	this.rstack.addStone(this.rpiece1);
	this.rstack.addStone(this.rpiece2);
	this.rstack.addStone(this.rpiece3);
	this.rstack.addStone(this.rpiece4);
	this.rstack.addStone(this.rpiece5);
	this.rstack.addStone(this.rpiece6);
	this.rstack.addStone(this.rpiece7);
	this.rstack.addStone(this.rpiece8);
	
	this.pickBoard = new MyPickableBoard(this);
	
	
	this.bplayertex = new CGFappearance(this);
	this.bplayertex.loadTexture("../resources/images/bplayer.png");
	this.rplayertex = new CGFappearance(this);
	this.rplayertex.loadTexture("../resources/images/rplayer.png");
	this.playerBoard = new MyQuad(this);
	// ANIMATIONS
	
	this.cps = [[0,0,0], [0,0,2]];
	this.LinAnim = new MyLinearAnim(this, this.cps, 1);

	
	// interface
	this.place = true;
	this.to_place = false; // aux
	this.playerturn = 1;
	
	this.move = false;
	//this.plane.addStone(this.bpiece1, 2, 2);
	//this.plane.addStone(this.rpiece1, 3, 3);
	// Materials


	
	//GUI options
	this.ligh0 = true;
	this.ligh1 = true;
	this.ligh2 = true;
	this.ligh3 = true;
	this.speed = 3;
	
	//Gui appearance
	this.currRobotAppearance = 0;
	this.robotAppearanceList = {};
	this.robotAppearanceList["PinkScary"] = 0;
	this.robotAppearanceList["MineCraft"] = 1;
	 
	//time
	
	this.time_date = new Date().getTime();
	
	//update
	this.setUpdatePeriod(10000);
	
	
};

LightingScene.prototype.initCameras = function() {
	this.camera = new CGFcamera(0.4, 0.1, 500, vec3.fromValues(30, 30, 30), vec3.fromValues(0, 0, 0));
};




LightingScene.prototype.initLights = function() {
	this.setGlobalAmbientLight(0.5,0.5,0.5, 1.0);

	//this.shader.bind();
	
	// Positions for four lights
	this.lights[0].setPosition(4, 6, 1, 1);
	this.lights[1].setPosition(10.5, 6.0, 1.0, 1.0);
	this.lights[2].setPosition(10.5, 6.0, 5.0, 1.0);
	this.lights[3].setPosition(4, 6.0, 5.0, 1.0);

	this.lights[0].setAmbient(0, 0, 0, 1);
	this.lights[0].setDiffuse(1.0, 1.0, 1.0, 1.0);
	this.lights[0].enable();

	this.lights[1].setAmbient(0, 0, 0, 1);
	this.lights[1].setDiffuse(1.0, 1.0, 1.0, 1.0);
	this.lights[1].enable();
	this.lights[2].enable();
	this.lights[3].enable();

	//this.shader.unbind();
};

LightingScene.prototype.updateLights = function() {
	for (i = 0; i < this.lights.length; i++)
		this.lights[i].update();
	if(this.ligh0==true){
		this.lights[0].enable();
	}
	else{
		this.lights[0].disable();
	}
	if(this.ligh1==true){
		this.lights[1].enable();
	}
	else{
		this.lights[1].disable();
	}
	if(this.ligh2==true){
		this.lights[2].enable();
	}
	else{
		this.lights[2].disable();
	}
	if(this.ligh3==true){
		this.lights[3].enable();
	}
	else{
		this.lights[3].disable();
	}
}


LightingScene.prototype.display = function() {
	//this.shader.bind();
	
	this.logPicking();
	if(this.ok_to_add){
					if(this.playerturn)
						this.add_board_to_stack(this.bstack, this.plane, this.casa_x, this.casa_z);
					else
						this.add_board_to_stack(this.rstack, this.plane, this.casa_x, this.casa_z);
					this.playerturn = !this.playerturn;
					this.ok_to_add = false;
					this.firsttime = false;
				}
	if(this.ok_to_move){
		this.movestoneto(this.old_x, this.old_z, this.casa_x, this.casa_z);
		this.playerturn = !this.playerturn;
	}
	this.clearPickRegistration();
	// ---- BEGIN Background, camera and axis setup

	// Clear image and depth buffer everytime we update the scene
	this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
    this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);
    this.gl.enable(this.gl.DEPTH_TEST);

	// Initialize Model-View matrix as identity (no transformation)
	this.updateProjectionMatrix();
	this.loadIdentity();

	// Apply transformations corresponding to the camera position relative to the origin
	this.applyViewMatrix();

	// Update all lights used
	this.updateLights();

	// Draw axis
	this.axis.display();


	// ---- END Background, camera and axis setup

	
	// ---- BEGIN Geometric transformation section

	// ---- END Geometric transformation section

	// DRAWING
	
	
	
	// Registers
	
	
	
	// MAIN BOARD
	
	this.pushMatrix();
		this.boardtex.apply();
		this.plane.display2();
		//console.log(this.plane.st);
	this.popMatrix();
	
	// STACKS
	
	this.pushMatrix();
		this.boardtex.apply();
		this.rstack.display2();
	this.popMatrix();
	this.pushMatrix();
		this.boardtex.apply();
		this.bstack.display2();
	this.popMatrix();
	
	//example board change  (place_piece)
	/*if(this.allanimsend() && this.place == true){
		this.add_board_to_stack(this.rstack, this.plane, 4,4);
		this.place = false;
		this.nextplace = true;
	}
	if(this.allanimsend() && this.nextplace == true){
		this.add_board_to_stack(this.bstack, this.plane, 5, 5);
		this.nextplace = false;
	}*/
	
	//Example Piece
	/*
	this.pusihMatrix();
		this.pieceapp.apply();
		//this.translate(-7, 0.5, -7);
		//this.LinAnim.move();
		
		this.registerForPick(1, this.bpiece1);
		if(this.bpiece1.z == 0){
		this.bpiece1.addAnimation(this.LinAnim);
		if(this.bpiece1.LinAnim.end == 1)
		this.bpiece1.change_coords(this.bpiece1.x, this.bpiece1.z + 1);
		}
		this.bpiece1.display();
	this.popMatrix(); 
	*/
	//Example Plog
	/*
	var okfunc = function(data){
		console.log(data.target.response);
	}
	var failfunc = function(){
		console.log("fail");
	}
	
	
	var matr = [2,3,4];
	var xxx = 1;
	var str = "pushi(["+matr+"])";
	getPrologRequest("handshake", okfunc,failfunc);
	*/
	
	// MAIN RUNNING FUNCTION
	//console.log(this.allanimsend());
	//if(this.place == true)
	//	place_piece();
	//this.shader.unbind();
	
	//this.pickBoard.display();
	if(this.move){
		this.pushMatrix();
			if(this.playerturn)
				this.bplayertex.apply();
			else
				this.rplayertex.apply();
			this.translate(0,0,-10);
			this.scale(10,10,1);
			this.playerBoard.display();
		this.popMatrix();
		this.move_piece();
	}
	
	
	if(this.check_if_empty_stacks() && !this.firsttime){
		this.place = false;
		this.to_place = false;
		this.move = true;
	}
	if(this.place && this.allanimsend()){
		this.pushMatrix();
			if(this.playerturn)
				this.bplayertex.apply();
			else
				this.rplayertex.apply();
			this.translate(0,0,-10);
			this.scale(10,10,1);
			this.playerBoard.display();
		this.popMatrix();
		this.place_piece();
	}
	
	
};


	//Example Plog
	function getPrologRequest(requestString, onSuccess, onError, port)
			{
				var requestPort = port || 8081
				var request = new XMLHttpRequest();
				request.open('GET', 'http://localhost:'+requestPort+'/'+requestString, true);

				request.onload = onSuccess || function(data){console.log("Request successful. Reply: " + data.target.response);};
				request.onerror = onError || function(){console.log("Error waiting for response");};

				request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
				request.send();
			}
		
			function makeRequest()
			{
				// Get Parameter Values
				var requestString = document.querySelector("#query_field").value;				
				
				// Make Request
				getPrologRequest(requestString, handleReply);
			}
			
			//Handle the Reply
			function handleReply(data){
				document.querySelector("#query_result").innerHTML=data.target.response;
			}

//example LogPicking
LightingScene.prototype.logPicking = function() {
	if(this.pickMode == false){
	if(this.pickResults != null && this.pickResults.length > 0){
		var obj = this.pickResults[0][0];
		if(obj){
			
			//PLACING
			if(this.to_place){
				this.casa_x = obj.x;
				this.casa_z = obj.z;
				var okfunc = function(data){
					if(data.target.response == 0)
						thisScene.ok_to_add = true;
					else{
						console.log("Place already taken!");
					}
				}
				var failfunc = function(){
					console.log("fail");
				}
				var thisScene = this;
				var m = JSON.stringify(this.plane.matrix);
				//console.log(JSON.stringify(this.plane.matrix));
				var mm = m.replace(/1/g, '\'B\'');
				var mmm = mm.replace(/2/g, '\'R\'');
				var mmmm = mmm.replace(/0/g, '.');
				var xx = this.casa_x + 1;
				var zz = this.casa_z + 1;
				var str = "put_piece_test("+mmmm+","+zz.toString()+","+xx.toString()+")";
				getPrologRequest(str, okfunc,failfunc);
			}
			else if(this.move && !this.displaypickb){
				this.old_x = obj.x;
				this.old_z = obj.z;
				this.displaypickb = true;
			}
			else if(this.move && this.displaypickb){
				this.casa_x = obj.x;
				this.casa_z = obj.z;
				var okfunc = function(data){
					console.log(data.target.response);
					if(data.target.response == 0)
						thisScene.ok_to_move = true;
					else{
						console.log("Place already taken!");
					}
				}
				var failfunc = function(){
					console.log("fail");
				}
				var thisScene = this;
				var m = JSON.stringify(this.plane.matrix);
				//console.log(JSON.stringify(this.plane.matrix));
				var mm = m.replace(/1/g, '\'B\'');
				var mmm = mm.replace(/2/g, '\'R\'');
				var mmmm = mmm.replace(/0/g, '.');
				var xx = this.casa_x + 1;
				var zz = this.casa_z + 1;
				var str = "put_piece_test("+mmmm+","+zz.toString()+","+xx.toString()+")";
				getPrologRequest(str, okfunc,failfunc);
			}
			this.pickResults.splice(0,this.pickResults.length);
		}
	}
	
	}
}

LightingScene.prototype.doSomething = function() {
	console.log("Doing Something..."); 
};

LightingScene.prototype.allanimsend = function(){
	if((this.rstack.pieces_vec[this.rstack.pieces_vec.length - 1] == null || this.rstack.pieces_vec[this.rstack.pieces_vec.length - 1].LinAnim.end == true )&&
	(this.bstack.pieces_vec[this.bstack.pieces_vec.length - 1] == null || this.bstack.pieces_vec[this.bstack.pieces_vec.length - 1].LinAnim.end == true ) &&
	(this.plane.pieces_vec[this.plane.pieces_vec.length - 1] == null || this.plane.pieces_vec[this.plane.pieces_vec.length - 1].LinAnim.end == true ))
		return true;
	else
		return false;
};

LightingScene.prototype.add_board_to_stack = function(stack, board, x, z){ // Dyslexic name function
	var popped_stone = stack.removePiece();
	board.addStoneFromStack(stack.rb, popped_stone, x, z);
};

LightingScene.prototype.place_piece = function(){
	this.pickBoard.display();
	this.to_place = true;
	// TO DO
};

LightingScene.prototype.check_if_empty_stacks = function(){
	return (this.bstack.pieces_vec.length == 0 && this.rstack.pieces_vec.length == 0);
};

LightingScene.prototype.move_piece = function(){
	if(this.playerturn && !this.displaypickb)
		this.registerbluestones = true;
	else
		this.registerredstones = true;
	
	if(this.displaypickb){
		this.pickBoard.display();
	}
	
};


LightingScene.prototype.movestoneto = function(x,z,new_x,new_z){
	for(i=0;i<this.plane.pieces_vec.length;i++){
		if(this.plane.pieces_vec[i].x == x && this.plane.pieces_vec[i].z == z){
			this.plane.pieces_vec[i].change_coords(new_x, new_z);
			this.plane.matrix[x][z]=0;
			if(this.plane.pieces_vec[i].rb == 1)
				this.plane.matrix[new_x][new_z]=1;
			else
				this.plane.matrix[new_x][new_z]=2;
			this.displaypickb = false;
			this.ok_to_move = false;
		}
	}
	
}
/*
LightingScene.prototype.registerbluestones = function(){
	var p = 1;
	for(i = 0; i<this.plane.pieces_vec.length;i++){
		if(this.plane.pieces_vec[i].rb ==1){
			this.registerForPick(p, this.plane.pieces_vec[i])
			p++;
		}
	}
};
LightingScene.prototype.registerredstones = function(){
	var p = 1;
	for(i = 0; i<this.plane.pieces_vec.length;i++){
		if(this.plane.pieces_vec[i].rb == 0){
			this.registerForPick(p, this.plane.pieces_vec[i])
			p++;
		}
	}
};
*/