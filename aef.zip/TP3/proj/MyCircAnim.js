function MyCircAnim(scene, id, time, center, raio, start_alfa, rotation_alfa){
	MyAnimation.call(this, scene, id, time);
    this.center = center;
    this.raio = raio;
    this.start_alfa = start_alfa;
    this.rotation_alfa = rotation_alfa;
    this.initMatrix = mat4.create();
    mat4.identity(this.initMatrix);
    mat4.rotateY(this.initMatrix, this.initMatrix, this.start_alfa);
    mat4.translate(this.initMatrix, this.initMatrix, vec3.fromValues(0, 0, this.raio));
	
    mat4.rotateY(this.initMatrix, this.initMatrix, this.rotatio_alfa > 0 ? Math.PI / 2 : -Math.PI / 2);
	this.done = false;
	//what to do

};

MyCircAnim.prototype = Object.create(MyAnimation.prototype);
MyCircAnim.prototype.constructor = MyCircAnim;

MyCircAnim.prototype.update = function(scene, delta) {
    delta = delta / 1000;

	console.log("delta " + delta + " act time " + this.actualtime);
    this.actualtime = Math.min(this.time, this.actualtime + delta);
	console.log("curr time ..  " + this.actualtime);
    if (this.actualtime == this.time) {
        this.done = true;
        return;
    }

    mat4.identity(this.m);

    mat4.translate(this.m, this.m, this.center);

    var rotation_beta = this.rotation_alfa * (this.actualtime / this.time);
    mat4.rotateY(this.m, this.m, rotation_beta);

    //mat4.multiply(this.m, this.m, this.initMatrix);
	mat4.multiply(scene.initial_matrix, this.m, this.initMatrix);
};

/*MyCircAnim.prototype.clone = function(delta) {
    return new CircularAnimation(this.id,
        this.time,
        this.center,
        this.rad,
        this.iang,
        this.rang);
};*/