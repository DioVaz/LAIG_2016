function MyPlane(scene, args) {
	this.scene = scene;
    this.args = args || [20];
    this.nrParts = this.args[0];
	this.matrix = [[0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0]];

	this.pieces_vec = [];
	this.st = new MyStone(this.scene);
    var nurbsSurface = new CGFnurbsSurface(1, 1, [0, 0, 1, 1], [0, 0, 1, 1], [
        [
            [0.5, 0, -0.5, 1],
            [0.5, 0, 0.5, 1]
        ],
        [
            [-0.5, 0, -0.5, 1],
            [-0.5, 0, 0.5, 1, 1]
        ]
    ]);
    var getSurfacePoint = function(u, v) {
        return nurbsSurface.getPoint(u, v);
    };
    CGFnurbsObject.call(this, scene, getSurfacePoint, this.nrParts, this.nrParts);
}

MyPlane.prototype = Object.create(CGFnurbsObject.prototype);
MyPlane.prototype.constructor = MyPlane;

MyPlane.prototype.updateTex = function(ampS, ampT) {};

MyPlane.prototype.display2 = function(){
	var p = 1;
	for(i=0; i<this.pieces_vec.length; i++){
		this.scene.pushMatrix();
			this.scene.pieceapp.apply();
			if(this.scene.registerbluestones && this.pieces_vec[i].rb == 1){
				this.scene.registerForPick(p, this.pieces_vec[i]);
				this.pieces_vec[i].display();
				this.scene.clearPickRegistration();
				p++;
			}
			else if(this.scene.registerredstones && this.pieces_vec[i].rb == 0){
				this.scene.registerForPick(p, this.pieces_vec[i]);
				this.pieces_vec[i].display();
				this.scene.clearPickRegistration();
				p++;
			}
			else{
				this.scene.clearPickRegistration();
				this.pieces_vec[i].display();
				this.scene.clearPickRegistration();
			}
			
		this.scene.popMatrix();
		//if(this.pieces_vec[i].LinAnim != null && this.pieces_vec[i].LinAnim.end != true)
		//	break;
	}
	this.scene.pushMatrix();
		this.scene.boardtex.apply();
		this.scene.scale(16,16,16);
		this.drawElements(this.primitiveType);
	this.scene.popMatrix();
	this.scene.clearPickRegistration();
	this.scene.registerbluestones = false;
	this.scene.registerredstones = false;
};


MyPlane.prototype.addStone = function(stone, x, z){
	this.matrix[x][z] = 1;
	stone.change_coords(x, z);
	this.pieces_vec.push(stone);
};

MyPlane.prototype.addStoneFromStack = function(rb, stone, x, z){
	
	if(rb == -1){
		stone.change_coords_from_red_stack(x,z);
		this.matrix[x][z] = 2;
	}
	else{
		this.matrix[x][z] = 1;
		stone.change_coords_from_blue_stack(x,z);
	}
	this.pieces_vec.push(stone);
}