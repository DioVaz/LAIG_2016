
function XMLscene() {
    CGFscene.call(this);
	this.grafo = [];
	this.grafo['root'] = new Node();
	this.initial_matrix = mat4.create();
	this.frustum = [];
	this.ref_length = null;
	this.texturelist = [];
	this.finaltexture = [];
	this.materiallist = [];
	this.finalmaterial = [];
	this.globalmaterial = [];
	this.dummy_material = new CGFappearance(this);
	this.lights = [];
	this.finalLight = [];
	this.ambient_rgba = [];
	this.x;
	this.y;
	this.z;
	this.LinAnim;
	this.circAnim;
	this.last_y;
	this.start_time;
	
}

XMLscene.prototype = Object.create(CGFscene.prototype);
XMLscene.prototype.constructor = XMLscene;

XMLscene.prototype.init = function (application) {
	
	
    CGFscene.prototype.init.call(this, application);
    this.initCameras();

    this.initLights();
	this.enableTextures(true);

    this.gl.clearColor(0.0, 0.0, 0.0, 1.0);

    this.gl.clearDepth(100.0);
    this.gl.enable(this.gl.DEPTH_TEST);
	this.gl.enable(this.gl.CULL_FACE);
    this.gl.depthFunc(this.gl.LEQUAL);

	this.axis=new CGFaxis(this);
	this.walltext = new CGFtexture(this, "../resources/images/wallapp.png");
	this.floortext = new CGFtexture(this, "../resources/images/floor.png");
	this.setUpdatePeriod(10);
};

XMLscene.prototype.initLights = function () {
	this.ambient_rgba[0] = 0; 
	this.ambient_rgba[1] = 0;
	this.ambient_rgba[2] = 0;
	this.ambient_rgba[3] = 0;
	this.setGlobalAmbientLight(this.ambient_rgba[0], this.ambient_rgba[1], this.ambient_rgba[2], this.ambient_rgba[3]);
	
	/*var indexLight = 0;
	var ind = 0;
	for(var x = 0; x<this.lights.length; x+= 18) {
		this.finalLight[indexLight] = this.lights[x];
		indexLight++;
		this.finalLight[indexLight] = new CGFlight(this, ind);
		if(this.lights[x+1] == 1){
			this.finalLight[indexLight].enable();
		}
		this.finalLight[indexLight].setPosition(this.lights[x+2], this.lights[x+3], this.lights[x+4], this.lights[x+5]);
		this.finalLight[indexLight].setAmbient(this.lights[x+6], this.lights[x+7], this.lights[x+8], this.lights[x+9]);
		this.finalLight[indexLight].setDiffuse(this.lights[x+10], this.lights[x+11], this.lights[x+12], this.lights[x+13]);
		this.finalLight[indexLight].setSpecular(this.lights[x+14], this.lights[x+15], this.lights[x+16], this.lights[x+17]);
		indexLight++;
	}*/
	
	
    //this.shader.bind();

	//this.lights[0].setPosition(2, 3, 3, 1);
    //this.lights[0].setDiffuse(1.0,1.0,1.0,1.0);
	this.lights[0].update();
	for(var u=0; u<this.lights.length ; u+=2){
		this.lights[u].setVisible(true);
		this.lights[u].update();
	}
 
    //this.shader.unbind();
};

XMLscene.prototype.initCameras = function () {
    this.camera = new CGFcamera(0.4, 0.1, 500, vec3.fromValues(15, 15, 15), vec3.fromValues(0, 0, 0));
};

XMLscene.prototype.setDefaultAppearance = function () {
    this.setAmbient(0.2, 0.4, 0.8, 1.0);
    this.setDiffuse(0.2, 0.4, 0.8, 1.0);
    this.setSpecular(0.2, 0.4, 0.8, 1.0);
    this.setShininess(1.0);	
	
};

// Handler called when the graph is finally loaded. 
// As loading is asynchronous, this may be called already after the application has started the run loop
XMLscene.prototype.onGraphLoaded = function () 
{
	
	var dataa = new Date();
	this.start_time = dataa.getTime();
	this.last_y = 0;
	var cps= [];
	var pc1 = [-2,0,-5];
	var pc2 = [-1, 3, 4];
	var pc3 = [3,4,3];
	cps[0] = pc1;
	cps[1] = pc2;
	cps[2] = pc3;
	var pc_nurb = [20];
	var pc_patch = [2, 20, 20, [[0,0,0], [8,2,2], [2,2,2], [3, -1.5, 0], [4, -2, 2], [5, 2, 2], [6, -1.5, 0], [7, -2, 2], [8, 2, 2]]];
	this.LinAnim = new MyLinearAnim(this, cps);
	this.circAnim = new MyCircAnim(this, 3, 4, pc3, 5, Math.PI/3, 2* Math.PI);
	this.teste = new MyQuad(this);
	this.teste2 = new MyQuad(this);
	this.d2d3 = new MyPlane(this, pc_nurb);
	this.patch = new MyPatch(this, pc_patch);
	this.vehic = new MyVehicle(this);
	var args2 = ["shaders/terrain.jpg", "shaders/heightmap.jpg"];
	this.terr = new MyTerrain(this, args2);
	this.x = 0;
	this.y=0;
	this.z=0;
	this.background_rgba = [this.graph.background_rgba_r, this.graph.background_rgba_g, this.graph.background_rgba_b, this.graph.background_rgba_a];
	this.gl.clearColor(this.background_rgba[0],this.background_rgba[1],this.background_rgba[2],this.background_rgba[3]);
	this.lights[0].setVisible(false);
    this.lights[0].enable();
	this.frustum = [this.graph.frustum_near, this.graph.frustum_far];
	this.ref_length = this.graph.reference_length;
	var index = 0;
	for(var x = 0; x<this.materiallist.length; x+= 18){
		this.finalmaterial[index] = this.materiallist[x];
		index++;
		this.finalmaterial[index] = new CGFappearance(this);
		this.finalmaterial[index].setShininess(this.materiallist[x+1]);
		this.finalmaterial[index].setSpecular(this.materiallist[x+2], this.materiallist[x+3], this.materiallist[x+4], this.materiallist[x+5]);
		this.finalmaterial[index].setDiffuse(this.materiallist[x+6], this.materiallist[x+7], this.materiallist[x+8], this.materiallist[x+9]);
		this.finalmaterial[index].setAmbient(this.materiallist[x+10], this.materiallist[x+11], this.materiallist[x+12], this.materiallist[x+13]);
		this.finalmaterial[index].setEmission(this.materiallist[x+14], this.materiallist[x+15], this.materiallist[x+16], this.materiallist[x+17]);
		index++;
	}
	var index_tex = 0;
	for(var m = 0; m<this.texturelist.length; m+= 4){
		this.finaltexture[index_tex] = this.texturelist[m];
		index_tex++;
		this.finaltexture[index_tex] = new CGFtexture(this, this.texturelist[m+1]);
		index_tex++;
	}
	this.ambient_rgba = [this.graph.ambient_rgba_r || 0, this.graph.ambient_rgba_g || 0, this.graph.ambient_rgba_b || 0, this.graph.ambient_rgba_a || 0];
	
	var indexl = 1;
	var ind = 0;
	for(var x = 0; x<this.graph.lightlist.length; x+= 18){
		/*this.lights[indexl] = this.graph.lightlist[x];
		indexl++;*/
		this.lights[indexl] = new CGFlight(this, ind);
		if(this.graph.lightlist[x+1] == 1){
			lights[indexl].enable();
		}
		this.lights[indexl].setPosition(this.graph.lightlist[x+2], this.graph.lightlist[x+3], this.graph.lightlist[x+4], this.graph.lightlist[x+5]);
		this.lights[indexl].setAmbient(this.graph.lightlist[x+6], this.graph.lightlist[x+7], this.graph.lightlist[x+8], this.graph.lightlist[x+9]);
		this.lights[indexl].setDiffuse(this.graph.lightlist[x+10], this.graph.lightlist[x+11], this.graph.lightlist[x+12], this.graph.lightlist[x+13]);
		this.lights[indexl].setSpecular(this.graph.lightlist[x+14], this.graph.lightlist[x+15], this.graph.lightlist[x+16], this.graph.lightlist[x+17]);
		indexl++;
	}
	
};

XMLscene.prototype.display = function () {
	// ---- BEGIN Background, camera and axis setup
   // this.shader.bind();
	
	// Clear image and depth buffer everytime we update the scene
    this.gl.viewport(0, 0, this.gl.canvas.width, this.gl.canvas.height);
    this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT);

	// Initialize Model-View matrix as identity (no transformation
	this.updateProjectionMatrix();
    this.loadIdentity();

	// Apply transformations corresponding to the camera position relative to the origin
	this.applyViewMatrix();

	// Draw axis
	this.def_app = new CGFappearance(this);
	//this.def_app.loadTexture("../resources/images/window.png");
	this.def_app.setShininess(1);
	this.axis.display();
	//console.log(this.def_app);

	//this.setDefaultAppearance();
	//this.def_app.apply();
	this.globalmaterial.push(this.def_app);
	//this.dummy_material.loadTexture("../resources/images/floor.png");
	// ---- END Background, camera and axis setup
	// it is important that things depending on the proper loading of the graph
	// only get executed after the graph has loaded correctly.
	// This is one possible way to do it
	if (this.graph.loadedOk)
	{
		mat4.identity(this.initial_matrix);
		mat4.translate(this.initial_matrix, this.initial_matrix, [this.graph.initials_translation_x, this.graph.initials_translation_y, this.graph.initials_translation_z]);
		mat4.rotate(this.initial_matrix, this.initial_matrix, this.graph.initials_rotation_x, [1, 0, 0]);
		mat4.rotate(this.initial_matrix, this.initial_matrix, this.graph.initials_rotation_y, [0, 1, 0]);
		mat4.rotate(this.initial_matrix, this.initial_matrix, this.graph.initials_rotation_z, [0, 0, 1]);
		mat4.scale(this.initial_matrix, this.initial_matrix, [this.graph.initials_scaling_x, this.graph.initials_scaling_y, this.graph.initials_scaling_z]);
		
		/*
		this.pushMatrix();
		this.translate(5, 5, 5);
		this.mycil = new Triangle(this, 1, 2, 3, 3,2,1,1,2,2);
		this.mycil.display();
		this.popMatrix();*/
	
		this.grafo['root'].display(this, mat4.create(), this.globalmaterial);
		
		
			
		for(var u=1; u<this.lights.length ; u++){
			this.lights[u].update();
			this.lights[u].enable();
		}
		//this.lights[0].update();
	}	

    //this.shader.unbind();
};

XMLscene.prototype.drawSphere = function(rad, slices, stacks){
	this.mycil = new Sphere(this, rad, slices, stacks);
	this.mycil.display();
	
}
XMLscene.prototype.drawTriangle = function(x0, y0, z0, x1, y1, z1, x2, y2, z2){
	this.tri = new MyTriangle(this, x0, y0, z0, x1, y1, z1, x2, y2, z2);
	this.tri.display();
}
